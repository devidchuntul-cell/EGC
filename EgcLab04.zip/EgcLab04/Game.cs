using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;
using OpenTK.Windowing.Common;
using OpenTK.Windowing.Desktop;
using OpenTK.Windowing.GraphicsLibraryFramework;

namespace Egc;

/// <summary>
/// Fereastra aplicației și bucla principală (main game loop).
/// Față de laboratorul 3: o scenă cu mai multe obiecte, fiecare cu matricea lui model,
/// o cameră cu matricele view și projection, tastatura și mouse-ul.
/// </summary>
public class Game : GameWindow
{
    // Obiecte care NU depind de OpenGL pot fi create imediat.
    private readonly Camera _camera = new();

    // Obiectele care folosesc OpenGL se creează în OnLoad (abia atunci există contextul OpenGL).
    private Shader _shader = null!;
    private readonly List<SceneObject> _scene = new();
    private readonly List<Transform2D> _initialTransforms = new();   // pentru tasta R

    // Starea aplicației (se modifică în OnUpdateFrame, se folosește în OnRenderFrame).
    private int _selected;            // indexul obiectului selectat în _scene (tasta Tab)
    private bool _wireframe;          // contur (true) sau plin (false)

    // Stare pentru T4 (pivot) și T5 (satelit)
    private Vector2 _pivot = Vector2.Zero;
    private Mesh _satelliteMesh = null!;
    private float _satelliteAngle;

    // Contoare afișate în titlul ferestrei.
    private readonly string _baseTitle;
    private double _secondTimer;
    private int _frames, _lastFrames;
    private bool _titleDirty = true;

    public Game(int width, int height, string title)
        : base(GameWindowSettings.Default,
               new NativeWindowSettings
               {
                   ClientSize = new Vector2i(width, height),
                   Title = title,
                   APIVersion = new Version(3, 3),          // cerem OpenGL 3.3 ...
                   Profile = ContextProfile.Core,           // ... profil Core (fără modul imediat)
                   Flags = ContextFlags.ForwardCompatible
               })
    {
        _baseTitle = title;
        VSync = VSyncMode.On;   // swap-ul bufferelor așteaptă reîmprospătarea monitorului
    }

    /// <summary>Apelată O SINGURĂ DATĂ, după crearea ferestrei și a contextului OpenGL.</summary>
    protected override void OnLoad()
    {
        base.OnLoad();

        Console.WriteLine($"OpenGL  : {GL.GetString(StringName.Version)}");
        Console.WriteLine($"Renderer: {GL.GetString(StringName.Renderer)}");

        GL.Viewport(0, 0, ClientSize.X, ClientSize.Y);
        _camera.Resize(ClientSize.X, ClientSize.Y);

        _shader = Shader.FromFiles("Shaders/shader.vert", "Shaders/shader.frag");

        // Scena: aceleași forme din laboratorul 3, acum plasate în lume prin Transform2D.
        // Depth (z) contează doar în perspectivă (tasta O, secțiunea 7.2).
        AddObject("pătrat", Shapes.Quad(),
                  new Transform2D { Position = new Vector2(-1.8f, -1.0f), Depth = -3.0f });
        AddObject("triunghi", Shapes.Triangle(),
                  new Transform2D { Position = new Vector2(-1.2f, 1.0f) });
        AddObject("hexagon", Shapes.RegularPolygon(6, 0.5f),
                  new Transform2D { Position = new Vector2(2.0f, 1.0f) });
        AddObject("cerc", Shapes.RegularPolygon(64, 0.5f),
                  new Transform2D { Position = new Vector2(0.8f, -0.6f), Depth = 2.0f });

        // T5: mesh-ul satelitului (un triunghi mic)
        _satelliteMesh = Shapes.Triangle();
    }

    /// <summary>Adaugă un obiect în scenă și reține transformarea lui inițială (pentru tasta R).</summary>
    private void AddObject(string name, Mesh mesh, Transform2D transform)
    {
        _scene.Add(new SceneObject(name, mesh, transform));
        _initialTransforms.Add(transform.Clone());
    }

    /// <summary>Apelată când se schimbă dimensiunea ferestrei.</summary>
    protected override void OnResize(ResizeEventArgs e)
    {
        base.OnResize(e);

        GL.Viewport(0, 0, e.Width, e.Height);   // zona ferestrei în care se desenează
        _camera.Resize(e.Width, e.Height);      // proiecția se adaptează la noul raport de aspect
    }

    /// <summary>Apelată la fiecare iterație a buclei: LOGICA aplicației (intrări, mișcare, timp).</summary>
    protected override void OnUpdateFrame(FrameEventArgs args)
    {
        base.OnUpdateFrame(args);

        if (KeyboardState.IsKeyDown(Keys.Escape))
        {
            Close();
        }

        // --- Obiectul selectat: tastatura (secțiunea 8) ------------------------------

        float dt = (float)args.Time;
        SceneObject sel = _scene[_selected];

        // T2: Shift ținut apăsat face toate cele trei mișcări ale obiectului de 3 ori mai rapide
        float speedMult = KeyboardState.IsKeyDown(Keys.LeftShift) ? 3.0f : 1.0f;

        float moveSpeed = 2.0f * speedMult;   // unități de lume pe secundă
        if (KeyboardState.IsKeyDown(Keys.Left)) sel.Transform.Position.X -= moveSpeed * dt;
        if (KeyboardState.IsKeyDown(Keys.Right)) sel.Transform.Position.X += moveSpeed * dt;
        if (KeyboardState.IsKeyDown(Keys.Down)) sel.Transform.Position.Y -= moveSpeed * dt;
        if (KeyboardState.IsKeyDown(Keys.Up)) sel.Transform.Position.Y += moveSpeed * dt;

        // T2: Q / E rotesc obiectul cu 90° pe secundă (Q trigonometric / pozitiv, E orar / negativ)
        float rotSpeed = 90.0f * speedMult;
        if (KeyboardState.IsKeyDown(Keys.Q)) sel.Transform.Rotation += rotSpeed * dt;
        if (KeyboardState.IsKeyDown(Keys.E)) sel.Transform.Rotation -= rotSpeed * dt;

        // T2: Z / X micșorează / măresc uniform cu un factor de 1,5 pe secundă, limitat între 0,1 și 10.
        // T2: Scalarea se face prin înmulțire și nu prin adunare deoarece scalarea este o operație multiplicativă
        // (procentuală / relativă la dimensiunea curentă) și trebuie să fie simetrică: mărirea urmată de
        // micșorare (s * 1.5 / 1.5 = s) readuce obiectul la dimensiunea inițială, iar scara rămâne strict
        // pozitivă (prin scădere s-ar putea ajunge la 0 sau la valori negative, inversând obiectul).
        float scaleExponent = dt * speedMult;
        if (KeyboardState.IsKeyDown(Keys.Z)) sel.Transform.Scale /= MathF.Pow(1.5f, scaleExponent);
        if (KeyboardState.IsKeyDown(Keys.X)) sel.Transform.Scale *= MathF.Pow(1.5f, scaleExponent);
        sel.Transform.Scale.X = Math.Clamp(sel.Transform.Scale.X, 0.1f, 10.0f);
        sel.Transform.Scale.Y = Math.Clamp(sel.Transform.Scale.Y, 0.1f, 10.0f);

        if (KeyboardState.IsKeyPressed(Keys.Tab)) _selected = (_selected + 1) % _scene.Count;
        if (KeyboardState.IsKeyPressed(Keys.O)) _camera.IsPerspective = !_camera.IsPerspective;
        if (KeyboardState.IsKeyPressed(Keys.F)) _wireframe = !_wireframe;
        if (KeyboardState.IsKeyPressed(Keys.R)) ResetScene();

        if (KeyboardState.IsKeyPressed(Keys.Tab) || KeyboardState.IsKeyPressed(Keys.O) ||
            KeyboardState.IsKeyPressed(Keys.R))
        {
            _titleDirty = true;
        }

        // --- Obiectul selectat: mouse-ul (secțiunea 9) -------------------------------

        // T3: la clic stânga, obiectul selectat se mută în punctul din lume aflat sub cursor (Depth nu se schimbă)
        if (MouseState.IsButtonPressed(MouseButton.Left))
        {
            sel.Transform.Position = ScreenToWorld(MouseState.Position);
        }

        // T4 (facultativ): clic dreapta stabilește pivotul în punctul din lume aflat sub cursor
        if (MouseState.IsButtonPressed(MouseButton.Right))
        {
            _pivot = ScreenToWorld(MouseState.Position);
        }

        // T4 (facultativ): cât timp este ținută apăsată tasta P, obiectul selectat se rotește în jurul pivotului cu 90°/s
        if (KeyboardState.IsKeyDown(Keys.P))
        {
            float deltaAngle = 90.0f * dt;
            float rad = MathHelper.DegreesToRadians(deltaAngle);
            float cos = MathF.Cos(rad);
            float sin = MathF.Sin(rad);

            Vector2 offset = sel.Transform.Position - _pivot;
            sel.Transform.Position = _pivot + new Vector2(
                offset.X * cos - offset.Y * sin,
                offset.X * sin + offset.Y * cos
            );
            sel.Transform.Rotation += deltaAngle;
        }

        // T5 (facultativ): actualizarea unghiului orbitei satelitului (o rotație completă de 360° la 4 secunde = 90°/s)
        _satelliteAngle += 90.0f * dt;

        // --- Camera: tastatura și rotița (secțiunea 6.2) -----------------------------

        float camSpeed = 3.0f / _camera.Zoom;                    // unități de lume pe secundă
        if (KeyboardState.IsKeyDown(Keys.A)) _camera.Position.X -= camSpeed * dt;
        if (KeyboardState.IsKeyDown(Keys.D)) _camera.Position.X += camSpeed * dt;
        if (KeyboardState.IsKeyDown(Keys.S)) _camera.Position.Y -= camSpeed * dt;
        if (KeyboardState.IsKeyDown(Keys.W)) _camera.Position.Y += camSpeed * dt;

        _camera.Zoom *= MathF.Pow(1.1f, MouseState.ScrollDelta.Y);   // un pas al rotiței = ±10 %
        _camera.Zoom = Math.Clamp(_camera.Zoom, 0.1f, 10.0f);

        // --- Titlul ferestrei: obiectul selectat, proiecția, cadre pe secundă --------

        _secondTimer += args.Time;
        if (_secondTimer >= 1.0)
        {
            _lastFrames = _frames;
            _frames = 0;
            _secondTimer -= 1.0;
            _titleDirty = true;
        }

        if (_titleDirty)
        {
            string projection = _camera.IsPerspective ? "perspectivă" : "ortografică";
            Title = $"{_baseTitle} | selectat: {_scene[_selected].Name} | proiecție {projection} | FPS: {_lastFrames}";
            _titleDirty = false;
        }
    }

    /// <summary>Apelată la fiecare iterație a buclei: DESENAREA unui cadru.</summary>
    protected override void OnRenderFrame(FrameEventArgs args)
    {
        base.OnRenderFrame(args);
        _frames++;

        // 1. Ștergem imaginea veche din back buffer.
        GL.ClearColor(0.12f, 0.14f, 0.18f, 1.0f);
        GL.Clear(ClearBufferMask.ColorBufferBit);

        // 2. Starea de rasterizare și programul shader.
        SetWireframe(_wireframe);
        _shader.Use();

        // 3. View și projection sunt aceleași pentru toate obiectele: le trimitem o singură dată.
        _shader.SetMatrix4("uView", _camera.ViewMatrix);
        _shader.SetMatrix4("uProjection", _camera.ProjectionMatrix);

        // 4. Fiecare obiect: matricea lui model, nuanța, apoi desenarea.
        foreach (SceneObject obj in _scene)
        {
            _shader.SetMatrix4("uModel", obj.Transform.ModelMatrix);
            _shader.SetColor("uTint", obj.Tint);
            obj.Mesh.Draw();
        }

        // T5 (facultativ): satelitul obiectului selectat.
        // T5: Când obiectul selectat este scalat, orbita satelitului (distanța față de obiect și forma ei)
        // precum și dimensiunea satelitului se scalează proporțional (dacă scalarea este neuniformă, orbita
        // circulară devine eliptică). Aceasta se întâmplă deoarece transformarea locală a satelitului
        // (inclusiv translația de rază 1,2) este înmulțită la dreapta cu ModelMatrix a obiectului selectat,
        // deci coordonatele orbitei trec prin matricea de scalare a obiectului părinte.
        Matrix4 satelliteLocal =
            Matrix4.CreateScale(0.3f, 0.3f, 1.0f)
          * Matrix4.CreateTranslation(1.2f, 0.0f, 0.0f)
          * Matrix4.CreateRotationZ(MathHelper.DegreesToRadians(_satelliteAngle));

        Matrix4 satelliteModel = satelliteLocal * _scene[_selected].Transform.ModelMatrix;
        _shader.SetMatrix4("uModel", satelliteModel);
        _shader.SetColor("uTint", Color4.White);
        _satelliteMesh.Draw();

        // 5. Afișăm cadrul terminat: back buffer <-> front buffer.
        SwapBuffers();
    }

    /// <summary>Apelată O SINGURĂ DATĂ, la închiderea ferestrei: eliberăm resursele GPU.</summary>
    protected override void OnUnload()
    {
        foreach (SceneObject obj in _scene)
        {
            obj.Dispose();
        }
        _satelliteMesh.Dispose();
        _shader.Dispose();

        base.OnUnload();
    }

    /// <summary>Transformă poziția mouse-ului (pixeli, origine stânga-sus) în coordonate de lume.</summary>
    private Vector2 ScreenToWorld(Vector2 mousePixels)
    {
        // Pasul 1: pixeli -> NDC (Normalized Device Coordinates, în [-1, 1]).
        // T3: Semnul minus (sau formula `1.0f - 2.0f * y / height`) apare în formula pentru y deoarece
        // sistemele de coordonate au axe verticale opuse: în coordonatele ferestrei (pixeli), originea (0, 0)
        // este în colțul stânga-sus și axa Y crește în jos, pe când în OpenGL (NDC) originea este în centru
        // și axa Y crește în sus (+1 sus, -1 jos).
        float ndcX = (2.0f * mousePixels.X / ClientSize.X) - 1.0f;
        float ndcY = 1.0f - (2.0f * mousePixels.Y / ClientSize.Y);

        // Pasul 2: NDC -> lume, folosind inversa matricei (ViewMatrix * ProjectionMatrix).
        Matrix4 invVP = Matrix4.Invert(_camera.ViewMatrix * _camera.ProjectionMatrix);
        Vector4 worldPos = new Vector4(ndcX, ndcY, 0.0f, 1.0f) * invVP;

        return new Vector2(worldPos.X, worldPos.Y) / worldPos.W;
    }

    /// <summary>Tasta R: obiectele revin la transformările inițiale, camera la starea inițială.</summary>
    private void ResetScene()
    {
        for (int i = 0; i < _scene.Count; i++)
        {
            _scene[i].Transform = _initialTransforms[i].Clone();
        }
        _camera.Reset();
        _pivot = Vector2.Zero;
    }

    /// <summary>
    /// Contur / plin. Dacă Visual Studio semnalează o eroare la primul parametru,
    /// folosiți aici tipul acceptat de versiunea voastră (vezi laboratorul 2, Problema 3):
    /// TriangleFace.FrontAndBack sau MaterialFace.FrontAndBack.
    /// </summary>
    private static void SetWireframe(bool wireframe)
    {
        GL.PolygonMode(TriangleFace.FrontAndBack, wireframe ? PolygonMode.Line : PolygonMode.Fill);
    }
}