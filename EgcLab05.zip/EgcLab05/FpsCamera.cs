using OpenTK.Mathematics;
using OpenTK.Windowing.GraphicsLibraryFramework;

namespace Egc;

/// <summary>
/// Camera FPS (first-person): orientarea vine din două unghiuri Euler, yaw și pitch,
/// controlate cu mouse-ul; deplasarea se face cu W A S D.
/// </summary>
public class FpsCamera : Camera
{
    private Vector3 _position;
    public override Vector3 Position => _position;

    public float Yaw { get; private set; }
    public float Pitch { get; private set; }
    public bool FreeFly { get; set; }

    private Vector3 _front = -Vector3.UnitZ;
    private Vector3 _right = Vector3.UnitX;
    private Vector3 _up = Vector3.UnitY;

    public override Vector3 Front => _front;

    // P4: Dacă MaxPitch ar fi 90°, la privirea verticală în sus (_front = (0, 1, 0)), _front și WorldUp devin
    // coliniari (paraleli), produsul vectorial Cross(_front, WorldUp) devine vectorul nul (0, 0, 0),
    // iar normalizarea lui produce NaN, făcând ca imaginea să dispară / să se blocheze (gimbal lock).
    public const float MaxPitch = 89.0f;
    public float MoveSpeed = 3.0f;
    public float SprintFactor = 2.5f;
    public float MouseSensitivity = 0.1f;
    public float FovStep = 2.0f;

    private static readonly Vector3 WorldUp = Vector3.UnitY;
    private static readonly Vector3 StartPosition = new(0.0f, 1.7f, 6.0f);
    private const float StartYaw = -90.0f;
    private const float StartPitch = 0.0f;

    public FpsCamera()
    {
        Reset();
    }

    public override string Name => FreeFly ? "FPS – zbor liber" : "FPS – mers";

    public override Matrix4 ViewMatrix =>
        Matrix4.LookAt(_position, _position + _front, _up);

    public override void Update(KeyboardState keyboard, MouseState mouse, Vector2 mouseDelta, float dt)
    {
        // --- 1. Orientarea: mouse-ul modifică yaw și pitch (TODO 5.5 a) -------------
        Yaw += mouseDelta.X * MouseSensitivity;
        Pitch -= mouseDelta.Y * MouseSensitivity;
        Pitch = Math.Clamp(Pitch, -MaxPitch, MaxPitch);

        UpdateVectors();

        // --- 2. FOV: rotița mouse-ului (TODO 5.1 c) --------------------------------
        if (mouse.ScrollDelta.Y != 0.0f)
        {
            ChangeFov(-mouse.ScrollDelta.Y * FovStep);
        }

        // --- 3. Deplasarea: W A S D + Space/Ctrl (TODO 5.6 & TODO 5.7) -------------
        Vector3 forward = FreeFly
            ? _front
            : Vector3.Normalize(new Vector3(_front.X, 0.0f, _front.Z));

        Vector3 move = Vector3.Zero;
        if (keyboard.IsKeyDown(Keys.W)) move += forward;
        if (keyboard.IsKeyDown(Keys.S)) move -= forward;
        if (keyboard.IsKeyDown(Keys.D)) move += _right;
        if (keyboard.IsKeyDown(Keys.A)) move -= _right;

        if (FreeFly)
        {
            if (keyboard.IsKeyDown(Keys.Space)) move += WorldUp;
            if (keyboard.IsKeyDown(Keys.LeftControl)) move -= WorldUp;
        }

        if (move.LengthSquared > 0.0f)
        {
            move.Normalize();
            float speed = MoveSpeed * (keyboard.IsKeyDown(Keys.LeftShift) ? SprintFactor : 1.0f);
            _position += move * speed * dt;
        }
    }

    /// <summary>
    /// Recalculează baza camerei din yaw și pitch (TODO 5.5 b).
    /// </summary>
    private void UpdateVectors()
    {
        float yawRad = MathHelper.DegreesToRadians(Yaw);
        float pitchRad = MathHelper.DegreesToRadians(Pitch);

        float cosPitch = MathF.Cos(pitchRad);
        _front = Vector3.Normalize(new Vector3(
            cosPitch * MathF.Cos(yawRad),
            MathF.Sin(pitchRad),
            cosPitch * MathF.Sin(yawRad)
        ));

        _right = Vector3.Normalize(Vector3.Cross(_front, WorldUp));
        _up = Vector3.Normalize(Vector3.Cross(_right, _front));
    }

    /// <summary>
    /// BONUS (Tema 7): așază camera FPS într-o poziție dată și o orientează pe o direcție dată,
    /// calculând yaw și pitch prin formulele inverse pentru comutare fără "salt".
    /// </summary>
    public void SetPose(Vector3 position, Vector3 direction)
    {
        _position = position;
        Vector3 dir = Vector3.Normalize(direction);

        float pitchRad = MathF.Asin(Math.Clamp(dir.Y, -1.0f, 1.0f));
        Pitch = Math.Clamp(MathHelper.RadiansToDegrees(pitchRad), -MaxPitch, MaxPitch);
        Yaw = MathHelper.RadiansToDegrees(MathF.Atan2(dir.Z, dir.X));

        UpdateVectors();
    }

    public override void Reset()
    {
        _position = StartPosition;
        Yaw = StartYaw;
        Pitch = StartPitch;
        FieldOfView = 60.0f;
        UpdateVectors();
    }

    public override IEnumerable<string> Describe()
    {
        yield return $"Poziție        : ({_position.X,6:F2}, {_position.Y,6:F2}, {_position.Z,6:F2})";
        yield return $"Yaw / pitch    : {NormalizeAngle(Yaw),7:F1}° / {Pitch,6:F1}°";
        yield return $"Front          : ({_front.X,6:F2}, {_front.Y,6:F2}, {_front.Z,6:F2})";
        yield return $"Right          : ({_right.X,6:F2}, {_right.Y,6:F2}, {_right.Z,6:F2})";
        yield return $"Up             : ({_up.X,6:F2}, {_up.Y,6:F2}, {_up.Z,6:F2})";
    }

    private static float NormalizeAngle(float degrees)
    {
        degrees %= 360.0f;
        if (degrees > 180.0f) degrees -= 360.0f;
        if (degrees <= -180.0f) degrees += 360.0f;
        return degrees;
    }
}