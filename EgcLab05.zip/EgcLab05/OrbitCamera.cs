﻿using OpenTK.Mathematics;
using OpenTK.Windowing.GraphicsLibraryFramework;

namespace Egc;

/// <summary>
/// Camera orbită (Tema 7): privește mereu spre un punct (Target) și se mișcă pe o sferă
/// în jurul lui, dată de Distance, Azimuth (în jurul lui Y) și Elevation (deasupra orizontalei).
/// </summary>
public class OrbitCamera : Camera
{
    public Vector3 Target { get; set; }
    public float Distance { get; private set; }
    public float Azimuth { get; private set; }     // grade
    public float Elevation { get; private set; }   // grade

    public const float MinDistance = 1.5f;
    public const float MaxDistance = 40.0f;
    public const float MaxElevation = 89.0f;

    public float MouseSensitivity = 0.25f;
    public float KeyRotateSpeed = 60.0f;           // grade/secundă (săgeți)
    public float PanSpeed = 5.0f;                  // unități/secundă (W A S D - bonus 2)
    public float ZoomStep = 0.8f;                  // unități la un pas al rotiței

    private static readonly Vector3 StartTarget = new(0.0f, 1.0f, -2.0f);
    private const float StartDistance = 10.0f;
    private const float StartAzimuth = 90.0f;
    private const float StartElevation = 25.0f;

    public OrbitCamera()
    {
        Reset();
    }

    public override string Name => "Orbită";

    /// <summary>
    /// Poziția pe sferă: țintă + distanță · (cos el · cos az, sin el, cos el · sin az).
    /// </summary>
    public override Vector3 Position
    {
        get
        {
            float azRad = MathHelper.DegreesToRadians(Azimuth);
            float elRad = MathHelper.DegreesToRadians(Elevation);
            float cosEl = MathF.Cos(elRad);

            Vector3 offset = new(
                cosEl * MathF.Cos(azRad),
                MathF.Sin(elRad),
                cosEl * MathF.Sin(azRad)
            );
            return Target + Distance * offset;
        }
    }

    public override Vector3 Front => Vector3.Normalize(Target - Position);

    public override Matrix4 ViewMatrix =>
        Matrix4.LookAt(Position, Target, Vector3.UnitY);

    public override void Update(KeyboardState keyboard, MouseState mouse, Vector2 mouseDelta, float dt)
    {
        // 1. Rotație cu mouse-ul (clic stânga ținut apăsat)
        if (mouse.IsButtonDown(MouseButton.Left))
        {
            Azimuth += mouseDelta.X * MouseSensitivity;
            Elevation += mouseDelta.Y * MouseSensitivity;
        }

        // 2. Rotație de la tastatură cu săgețile
        if (keyboard.IsKeyDown(Keys.Left)) Azimuth += KeyRotateSpeed * dt;
        if (keyboard.IsKeyDown(Keys.Right)) Azimuth -= KeyRotateSpeed * dt;
        if (keyboard.IsKeyDown(Keys.Up)) Elevation += KeyRotateSpeed * dt;
        if (keyboard.IsKeyDown(Keys.Down)) Elevation -= KeyRotateSpeed * dt;

        Elevation = Math.Clamp(Elevation, -MaxElevation, MaxElevation);

        // 3. Rotița mouse-ului modifică distanța (nu FOV-ul)
        if (mouse.ScrollDelta.Y != 0.0f)
        {
            Distance = Math.Clamp(Distance - mouse.ScrollDelta.Y * ZoomStep, MinDistance, MaxDistance);
        }

        // 4. BONUS 2: W A S D mută ținta în planul orizontal
        Vector3 flatFront = new(Front.X, 0.0f, Front.Z);
        if (flatFront.LengthSquared > 1e-6f)
        {
            flatFront.Normalize();
            Vector3 flatRight = Vector3.Normalize(Vector3.Cross(flatFront, Vector3.UnitY));

            Vector3 pan = Vector3.Zero;
            if (keyboard.IsKeyDown(Keys.W)) pan += flatFront;
            if (keyboard.IsKeyDown(Keys.S)) pan -= flatFront;
            if (keyboard.IsKeyDown(Keys.D)) pan += flatRight;
            if (keyboard.IsKeyDown(Keys.A)) pan -= flatRight;

            if (pan.LengthSquared > 0.0f)
            {
                pan.Normalize();
                float speed = PanSpeed * (keyboard.IsKeyDown(Keys.LeftShift) ? 2.5f : 1.0f);
                Target += pan * speed * dt;
            }
        }
    }

    /// <summary>
    /// BONUS 1 (Tema 7): sincronizează camera orbită cu camera FPS la comutare fără "salt".
    /// Ținta devine punctul aflat la o distanță fixă (5) în fața camerei FPS, iar unghiurile se
    /// calculează din vectorul unitar țintă -> cameră (o = -front).
    /// </summary>
    public void SyncFromFps(FpsCamera fps, float focusDistance = 5.0f)
    {
        Distance = Math.Clamp(focusDistance, MinDistance, MaxDistance);
        Target = fps.Position + fps.Front * Distance;

        Vector3 o = -fps.Front; // vectorul unitar țintă -> cameră
        float elRad = MathF.Asin(Math.Clamp(o.Y, -1.0f, 1.0f));
        Elevation = Math.Clamp(MathHelper.RadiansToDegrees(elRad), -MaxElevation, MaxElevation);
        Azimuth = MathHelper.RadiansToDegrees(MathF.Atan2(o.Z, o.X));
    }

    public override void Reset()
    {
        Target = StartTarget;
        Distance = StartDistance;
        Azimuth = StartAzimuth;
        Elevation = StartElevation;
        FieldOfView = 60.0f;
    }

    public override IEnumerable<string> Describe()
    {
        Vector3 pos = Position;
        yield return $"Țintă          : ({Target.X,6:F2}, {Target.Y,6:F2}, {Target.Z,6:F2})";
        yield return $"Distanță       : {Distance,6:F2}";
        yield return $"Azimut / elev. : {Azimuth,7:F1}° / {Elevation,6:F1}°";
        yield return $"Poziție        : ({pos.X,6:F2}, {pos.Y,6:F2}, {pos.Z,6:F2})";
    }
}