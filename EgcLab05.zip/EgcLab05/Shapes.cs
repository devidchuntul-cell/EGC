using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;

namespace Egc;

/// <summary>
/// Fabrica de forme 3D: fiecare metodă calculează vârfurile și indicii unei forme (mesh procedural)
/// și construiește un obiect Mesh.
/// </summary>
public static class Shapes
{
    // =====================================================================================
    // Forme pentru orientare (linii)
    // =====================================================================================

    public static Mesh Grid(int halfSize, float step, Color4 color)
    {
        int linesPerDirection = 2 * halfSize + 1;
        var vertices = new float[linesPerDirection * 2 * 2 * Mesh.FloatsPerVertex];
        var indices = new uint[linesPerDirection * 2 * 2];

        float extent = halfSize * step;
        int v = 0;
        for (int k = -halfSize; k <= halfSize; k++)
        {
            float c = k * step;
            SetVertex(vertices, v++, c, 0.0f, -extent, color);
            SetVertex(vertices, v++, c, 0.0f, extent, color);
            SetVertex(vertices, v++, -extent, 0.0f, c, color);
            SetVertex(vertices, v++, extent, 0.0f, c, color);
        }
        for (int i = 0; i < indices.Length; i++)
        {
            indices[i] = (uint)i;
        }

        return new Mesh(vertices, indices, PrimitiveType.Lines);
    }

    public static Mesh Axes(float length)
    {
        var vertices = new float[6 * Mesh.FloatsPerVertex];
        SetVertex(vertices, 0, 0, 0, 0, 1, 0, 0);
        SetVertex(vertices, 1, length, 0, 0, 1, 0, 0);
        SetVertex(vertices, 2, 0, 0, 0, 0, 1, 0);
        SetVertex(vertices, 3, 0, length, 0, 0, 1, 0);
        SetVertex(vertices, 4, 0, 0, 0, 0, 0, 1);
        SetVertex(vertices, 5, 0, 0, length, 0, 0, 1);
        uint[] indices = { 0, 1, 2, 3, 4, 5 };
        return new Mesh(vertices, indices, PrimitiveType.Lines);
    }

    // =====================================================================================
    // Forme 3D (triunghiuri)
    // =====================================================================================

    public static Mesh Pyramid()
    {
        const float h = 0.5f;
        var vertices = new float[16 * Mesh.FloatsPerVertex];
        var indices = new uint[4 * 3 + 6];

        var apex = new Vector3(0, h, 0);
        Vector3 frontLeft = new(-h, -h, h), frontRight = new(h, -h, h);
        Vector3 backRight = new(h, -h, -h), backLeft = new(-h, -h, -h);

        AddTriangle(vertices, indices, 0, frontLeft, frontRight, apex, ColorUtil.FromHsv(0.00f, 0.8f, 1.0f));
        AddTriangle(vertices, indices, 1, frontRight, backRight, apex, ColorUtil.FromHsv(0.15f, 0.8f, 1.0f));
        AddTriangle(vertices, indices, 2, backRight, backLeft, apex, ColorUtil.FromHsv(0.30f, 0.8f, 1.0f));
        AddTriangle(vertices, indices, 3, backLeft, frontLeft, apex, ColorUtil.FromHsv(0.55f, 0.8f, 1.0f));

        Color4 baseColor = new(0.35f, 0.35f, 0.35f, 1.0f);
        SetVertex(vertices, 12, backLeft, baseColor);
        SetVertex(vertices, 13, backRight, baseColor);
        SetVertex(vertices, 14, frontRight, baseColor);
        SetVertex(vertices, 15, frontLeft, baseColor);
        uint[] baseIndices = { 12, 13, 14, 14, 15, 12 };
        baseIndices.CopyTo(indices, 12);

        return new Mesh(vertices, indices);
    }

    /// <summary>
    /// Cubul cu latura 1, centrat în origine.
    /// Culori: +X roșu, -X cyan, +Y verde, -Y magenta, +Z albastru, -Z galben.
    /// </summary>
    public static Mesh Cube()
    {
        const float h = 0.5f;
        var vertices = new float[24 * Mesh.FloatsPerVertex];
        var indices = new uint[36];

        // Fața 0: +Z (față, albastru). Privită din +Z: dreapta = +X, sus = +Y.
        AddFace(vertices, indices, 0,
                new Vector3(-h, -h, h), new Vector3(h, -h, h), new Vector3(h, h, h), new Vector3(-h, h, h),
                new Color4(0.2f, 0.4f, 1.0f, 1.0f));

        // Fața 1: +X (dreapta, roșu). Privită din +X: dreapta = -Z, sus = +Y.
        AddFace(vertices, indices, 1,
                new Vector3(h, -h, h), new Vector3(h, -h, -h), new Vector3(h, h, -h), new Vector3(h, h, h),
                new Color4(1.0f, 0.2f, 0.2f, 1.0f));

        // TODO 5.3: fețele 2..5
        // Fața 2: -Z (spate, galben). Privită din -Z: dreapta = -X, sus = +Y.
        AddFace(vertices, indices, 2,
                new Vector3(h, -h, -h), new Vector3(-h, -h, -h), new Vector3(-h, h, -h), new Vector3(h, h, -h),
                new Color4(1.0f, 0.9f, 0.2f, 1.0f));

        // Fața 3: -X (stânga, cyan). Privită din -X: dreapta = +Z, sus = +Y.
        AddFace(vertices, indices, 3,
                new Vector3(-h, -h, -h), new Vector3(-h, -h, h), new Vector3(-h, h, h), new Vector3(-h, h, -h),
                new Color4(0.2f, 0.9f, 1.0f, 1.0f));

        // Fața 4: +Y (sus, verde). Privită din +Y: dreapta = +X, sus = -Z.
        AddFace(vertices, indices, 4,
                new Vector3(-h, h, h), new Vector3(h, h, h), new Vector3(h, h, -h), new Vector3(-h, h, -h),
                new Color4(0.2f, 0.9f, 0.3f, 1.0f));

        // Fața 5: -Y (jos, magenta). Privită din -Y: dreapta = +X, sus = +Z.
        AddFace(vertices, indices, 5,
                new Vector3(-h, -h, -h), new Vector3(h, -h, -h), new Vector3(h, -h, h), new Vector3(-h, -h, h),
                new Color4(0.95f, 0.2f, 0.9f, 1.0f));

        return new Mesh(vertices, indices);
    }

    /// <summary>
    /// Sfera UV de rază <paramref name="radius"/>.
    /// P3: Pentru 32 de felii și 16 benzi:
    /// - Numărul de vârfuri = (16 + 1) * (32 + 1) = 17 * 33 = 561 vârfuri.
    /// - Numărul de triunghiuri = 16 * 32 * 2 = 1024 triunghiuri (3072 indici).
    /// - Dintre acestea, 64 de triunghiuri sunt degenerate (au aria 0 și nu se văd): cele 32 din banda de la polul
    ///   sud (i = 0, triunghiurile de jos au două vârfuri suprapuse în polul sud) și cele 32 din banda de la polul
    ///   nord (i = stacks - 1, triunghiurile de sus au două vârfuri suprapuse în polul nord), deoarece la poli
    ///   cos(latitude) = 0 și toate vârfurile de pe rândul polului coincid în același punct (0, ±radius, 0).
    /// </summary>
    public static Mesh Sphere(float radius, int slices, int stacks)
    {
        int columns = slices + 1;
        int rows = stacks + 1;
        var vertices = new float[rows * columns * Mesh.FloatsPerVertex];
        var indices = new uint[stacks * slices * 6];

        // 1. Vârfurile: rândul i (de jos în sus), coloana j (spre est).
        for (int i = 0; i < rows; i++)
        {
            float v = (float)i / stacks;
            float latitude = -MathF.PI / 2.0f + v * MathF.PI;
            float cosLat = MathF.Cos(latitude);
            float sinLat = MathF.Sin(latitude);

            for (int j = 0; j < columns; j++)
            {
                float u = (float)j / slices;
                float longitude = u * 2.0f * MathF.PI;

                // TODO 5.4 (a): coordonate sferice -> carteziene
                float x = radius * cosLat * MathF.Cos(longitude);
                float y = radius * sinLat;
                float z = radius * cosLat * MathF.Sin(longitude);

                SetVertex(vertices, i * columns + j, x, y, z, u, v, 0.35f);
            }
        }

        // 2. Indicii: fiecare celulă a grilei = 2 triunghiuri.
        int k = 0;
        for (int i = 0; i < stacks; i++)
        {
            for (int j = 0; j < slices; j++)
            {
                uint bottomLeft = (uint)(i * columns + j);
                uint bottomRight = bottomLeft + 1;
                uint topLeft = bottomLeft + (uint)columns;
                uint topRight = topLeft + 1;

                // TODO 5.4 (b): cele două triunghiuri în sens trigonometric privite din afară
                // (în sistemul nostru, longitude crește de la +X spre +Z, deci spre stânga când privim din afară;
                // ordinea trigonometrică privită din afară este bottomLeft - topRight - bottomRight și topRight - bottomLeft - topLeft)
                indices[k++] = bottomLeft;
                indices[k++] = topRight;
                indices[k++] = bottomRight;

                indices[k++] = topRight;
                indices[k++] = bottomLeft;
                indices[k++] = topLeft;
            }
        }

        return new Mesh(vertices, indices);
    }

    /// <summary>
    /// FACULTATIV (TODO 5.8 / P7*): cilindrul cu axa pe Y, de rază <paramref name="radius"/> și înălțime
    /// <paramref name="height"/>, cu <paramref name="segments"/> segmente pe circumferință.
    /// </summary>
    public static Mesh Cylinder(float radius, float height, int segments)
    {
        float halfH = height / 2.0f;
        int cols = segments + 1;

        // Vârfuri:
        // - Suprafața laterală: 2 rânduri (jos și sus) × (segments + 1) coloane
        // - Capacul de sus: 1 centru + (segments + 1) vârfuri pe cerc
        // - Capacul de jos: 1 centru + (segments + 1) vârfuri pe cerc
        int sideVertCount = 2 * cols;
        int capVertCount = 1 + cols;
        int totalVerts = sideVertCount + 2 * capVertCount;

        var vertices = new float[totalVerts * Mesh.FloatsPerVertex];
        var indices = new uint[segments * 6 + segments * 3 + segments * 3];

        int vIdx = 0;
        int iIdx = 0;

        // 1. Suprafața laterală (rândul 0 jos, rândul 1 sus)
        for (int row = 0; row < 2; row++)
        {
            float y = row == 0 ? -halfH : halfH;
            float vCoord = row;
            for (int j = 0; j < cols; j++)
            {
                float u = (float)j / segments;
                float angle = u * 2.0f * MathF.PI;
                float x = radius * MathF.Cos(angle);
                float z = radius * MathF.Sin(angle);
                SetVertex(vertices, vIdx++, x, y, z, ColorUtil.FromHsv(u, 0.75f, 0.95f));
            }
        }

        for (int j = 0; j < segments; j++)
        {
            uint bl = (uint)j;
            uint br = bl + 1;
            uint tl = bl + (uint)cols;
            uint tr = tl + 1;

            indices[iIdx++] = bl; indices[iIdx++] = tr; indices[iIdx++] = br;
            indices[iIdx++] = tr; indices[iIdx++] = bl; indices[iIdx++] = tl;
        }

        // 2. Capacul de sus (+Y, sens trigonometric privit de sus: centru -> j+1 -> j)
        int topCenter = vIdx;
        SetVertex(vertices, vIdx++, 0.0f, halfH, 0.0f, new Color4(0.85f, 0.9f, 1.0f, 1.0f));
        int topRingStart = vIdx;
        for (int j = 0; j < cols; j++)
        {
            float angle = 2.0f * MathF.PI * j / segments;
            SetVertex(vertices, vIdx++, radius * MathF.Cos(angle), halfH, radius * MathF.Sin(angle),
                      new Color4(0.75f, 0.8f, 0.95f, 1.0f));
        }
        for (int j = 0; j < segments; j++)
        {
            indices[iIdx++] = (uint)topCenter;
            indices[iIdx++] = (uint)(topRingStart + j + 1);
            indices[iIdx++] = (uint)(topRingStart + j);
        }

        // 3. Capacul de jos (-Y, sens trigonometric privit de jos: centru -> j -> j+1)
        int botCenter = vIdx;
        SetVertex(vertices, vIdx++, 0.0f, -halfH, 0.0f, new Color4(0.5f, 0.55f, 0.65f, 1.0f));
        int botRingStart = vIdx;
        for (int j = 0; j < cols; j++)
        {
            float angle = 2.0f * MathF.PI * j / segments;
            SetVertex(vertices, vIdx++, radius * MathF.Cos(angle), -halfH, radius * MathF.Sin(angle),
                      new Color4(0.45f, 0.5f, 0.6f, 1.0f));
        }
        for (int j = 0; j < segments; j++)
        {
            indices[iIdx++] = (uint)botCenter;
            indices[iIdx++] = (uint)(botRingStart + j);
            indices[iIdx++] = (uint)(botRingStart + j + 1);
        }

        return new Mesh(vertices, indices);
    }

    // =====================================================================================
    // Funcții ajutătoare
    // =====================================================================================

    private static void AddFace(float[] vertices, uint[] indices, int face,
                                Vector3 a, Vector3 b, Vector3 c, Vector3 d, Color4 color)
    {
        int first = 4 * face;
        SetVertex(vertices, first, a, color);
        SetVertex(vertices, first + 1, b, color);
        SetVertex(vertices, first + 2, c, color);
        SetVertex(vertices, first + 3, d, color);

        uint f = (uint)first;
        int k = 6 * face;
        indices[k] = f; indices[k + 1] = f + 1; indices[k + 2] = f + 2;
        indices[k + 3] = f + 2; indices[k + 4] = f + 3; indices[k + 5] = f;
    }

    private static void AddTriangle(float[] vertices, uint[] indices, int face,
                                    Vector3 a, Vector3 b, Vector3 c, Color4 color)
    {
        int first = 3 * face;
        SetVertex(vertices, first, a, color);
        SetVertex(vertices, first + 1, b, color);
        SetVertex(vertices, first + 2, c, color);
        indices[first] = (uint)first;
        indices[first + 1] = (uint)first + 1;
        indices[first + 2] = (uint)first + 2;
    }

    private static void SetVertex(float[] vertices, int index, float x, float y, float z, float r, float g, float b)
    {
        int i = index * Mesh.FloatsPerVertex;
        vertices[i] = x;
        vertices[i + 1] = y;
        vertices[i + 2] = z;
        vertices[i + 3] = r;
        vertices[i + 4] = g;
        vertices[i + 5] = b;
    }

    private static void SetVertex(float[] vertices, int index, float x, float y, float z, Color4 color) =>
        SetVertex(vertices, index, x, y, z, color.R, color.G, color.B);

    private static void SetVertex(float[] vertices, int index, Vector3 p, Color4 color) =>
        SetVertex(vertices, index, p.X, p.Y, p.Z, color.R, color.G, color.B);
}