namespace Egc;

/// <summary>
/// NOU: ceasul aplicației (secțiunea 2). Primește la fiecare cadru timpul REAL scurs
/// (args.Time din OnUpdateFrame) și calculează timpul de JOC (DeltaTime, TotalTime),
/// pe care îl folosesc animațiile: poate fi pus pe pauză, încetinit sau accelerat.
/// </summary>
public sealed class Clock
{
    public const float MaxDelta = 0.1f;
    public const float MinScale = 0.125f;
    public const float MaxScale = 4.0f;

    public float RealDeltaTime { get; private set; }
    public float DeltaTime { get; private set; }
    public double TotalTime { get; private set; }
    public float TimeScale { get; private set; } = 1.0f;
    public bool Paused { get; set; }

    /// <summary>Apelată O DATĂ pe cadru, la începutul lui Game.OnUpdateFrame.</summary>
    public void Tick(double realSeconds)
    {
        RealDeltaTime = (float)realSeconds;

        // TODO 6.1: timpul de joc
        // P1 (Întrebare): Dacă pasul de timp nu ar fi limitat la MaxDelta, la o blocare temporară
        // a aplicației (ex. tragerea ferestrei cu mouse-ul sau B), dt ar fi foarte mare (ex. 0,5 s).
        // Un obiect care cade sub gravitație ar acumula o viteză și o deplasare uriașe într-un singur cadru,
        // "teletransportându-se" în jos și putând trece prin podea/obstacole fără să fie detectată coliziunea (tunneling).
        float clampedDelta = MathF.Min(RealDeltaTime, MaxDelta);
        DeltaTime = Paused ? 0.0f : clampedDelta * TimeScale;

        TotalTime += DeltaTime;
    }

    public void ChangeScale(float factor)
    {
        TimeScale = Math.Clamp(TimeScale * factor, MinScale, MaxScale);
    }

    public void ResetScale() => TimeScale = 1.0f;
}