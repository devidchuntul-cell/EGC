namespace Egc;

public delegate float EasingFunction(float t);

public static class Easing
{
    public static float Lerp(float a, float b, float t) => a + (b - a) * t;

    public static float Linear(float t) => t;

    public static float EaseIn(float t) => t * t;

    /// <summary>Pornește repede și frânează la sosire.</summary>
    public static float EaseOut(float t)
    {
        float inv = 1.0f - t;
        return 1.0f - inv * inv;
    }

    /// <summary>Pornește încet, accelerează, apoi frânează la sosire.</summary>
    public static float EaseInOut(float t)
    {
        return t * t * (3.0f - 2.0f * t);
    }

    public static readonly (string Name, EasingFunction Function)[] All =
    {
        ("Linear", Linear),
        ("EaseIn", EaseIn),
        ("EaseOut", EaseOut),
        ("EaseInOut", EaseInOut),
    };
}