﻿// Varianta B: evită obstacolele (cu bonus: marcaje mobile pe drum)
using OpenTK.Mathematics;
using OpenTK.Windowing.GraphicsLibraryFramework;

namespace Egc.Teme;

public sealed class DodgeObstaclesScene : Scene
{
    private const string MoveLeft = "banda din stânga";
    private const string MoveRight = "banda din dreapta";
    private const string JumpAction = "salt";
    private const string RestartAction = "joc nou";

    private static readonly float[] LaneX = { -2.2f, 0.0f, 2.2f };
    private const float PlayerY = 0.5f;
    private const float PlayerZ = 3.0f;
    private const float Gravity = 24.0f;
    private const float JumpSpeed = 9.5f;

    private readonly Random _rng = new();

    private SceneObject _playerRoot = null!;
    private SceneObject _playerBody = null!;
    private SceneObject _playerHat = null!;
    private Tween _laneTween = null!;
    private int _currentLane = 1;

    private float _verticalSpeed;
    private float _jumpHeight;

    private Mesh _cubeMesh = null!;
    private readonly List<SceneObject> _roadStripes = new();

    private sealed class Obstacle
    {
        public SceneObject Obj = null!;
        public Vector3 HalfExtents;
        public bool IsTall;
    }

    private readonly List<Obstacle> _obstacles = new();
    private float _spawnTimer;
    private float _worldSpeed;
    private float _score;
    private float _bestScore;
    private bool _gameOver;

    public override string Name => "Varianta B – evită obstacolele";

    public override string Status =>
        _gameOver
            ? $"GAME OVER | scor: {_score:F1} s | record: {_bestScore:F1} s (R = restart)"
            : $"scor: {_score:F1} s | record: {_bestScore:F1} s";

    public override IEnumerable<string> ActionNames => new[]
    {
        MoveLeft, MoveRight, JumpAction, RestartAction
    };

    public override void Load(Input input)
    {
        CameraPosition = new Vector3(0.0f, 5.2f, 9.5f);
        CameraTarget = new Vector3(0.0f, 1.0f, -4.0f);

        input.Bind(MoveLeft, Keys.A, Keys.Left);
        input.Bind(MoveRight, Keys.D, Keys.Right);
        input.Bind(JumpAction, Keys.Space, Keys.W, Keys.Up);
        input.Bind(RestartAction, Keys.R);

        _cubeMesh = AddMesh(Shapes.ShadedCube());
        Mesh diskMesh = AddMesh(Shapes.ShadedCylinder(0.5f, 0.02f, 24));

        // Drumul
        SceneObject road = AddObject("drum", _cubeMesh);
        road.Transform.Position = new Vector3(0.0f, -0.05f, -18.0f);
        road.Transform.Scale = new Vector3(7.6f, 0.1f, 52.0f);
        road.Tint = new Color4(0.22f, 0.24f, 0.28f, 1.0f);

        // Borduri laterale
        foreach (float side in new[] { -3.9f, 3.9f })
        {
            SceneObject curb = AddObject("bordură", _cubeMesh);
            curb.Transform.Position = new Vector3(side, 0.08f, -18.0f);
            curb.Transform.Scale = new Vector3(0.25f, 0.16f, 52.0f);
            curb.Tint = new Color4(0.85f, 0.85f, 0.9f, 1.0f);
        }

        // BONUS: marcaje discontinue între cele 3 benzi care se deplasează odată cu lumea
        for (int i = 0; i < 12; i++)
        {
            float z = 6.0f - i * 4.2f;
            foreach (float lineX in new[] { -1.1f, 1.1f })
            {
                SceneObject stripe = AddObject("marcaj", _cubeMesh);
                stripe.Transform.Position = new Vector3(lineX, 0.01f, z);
                stripe.Transform.Scale = new Vector3(0.12f, 0.02f, 1.8f);
                stripe.Tint = new Color4(0.95f, 0.85f, 0.25f, 1.0f);
                _roadStripes.Add(stripe);
            }
        }

        // Ierarhie părinte-copil pentru jucător: rădăcina poartă poziția și umbra, corpul și viziera sunt copii
        _playerRoot = AddObject("jucător_rădăcină", null);
        _playerRoot.Transform.Position = new Vector3(LaneX[_currentLane], 0.0f, PlayerZ);

        SceneObject shadow = AddObject("umbră", diskMesh, _playerRoot);
        shadow.Transform.Position = new Vector3(0.0f, 0.02f, 0.0f);
        shadow.Transform.Scale = new Vector3(1.1f, 1.0f, 1.1f);
        shadow.Tint = new Color4(0.05f, 0.05f, 0.08f, 1.0f);

        _playerBody = AddObject("jucător_corp", _cubeMesh, _playerRoot);
        _playerBody.Transform.Position = new Vector3(0.0f, PlayerY, 0.0f);
        _playerBody.Tint = new Color4(0.25f, 0.85f, 0.95f, 1.0f);

        _playerHat = AddObject("jucător_vizieră", _cubeMesh, _playerBody);
        _playerHat.Transform.Position = new Vector3(0.0f, 0.22f, -0.45f);
        _playerHat.Transform.Scale = new Vector3(0.75f, 0.22f, 0.2f);
        _playerHat.Tint = new Color4(1.0f, 0.95f, 0.3f, 1.0f);

        _laneTween = new Tween(
            new Vector3(LaneX[_currentLane], 0.0f, PlayerZ),
            new Vector3(LaneX[_currentLane], 0.0f, PlayerZ),
            0.15f,
            Easing.EaseOut);

        ResetGame();
    }

    private void ResetGame()
    {
        foreach (Obstacle obs in _obstacles)
        {
            Objects.Remove(obs.Obj);
        }
        _obstacles.Clear();

        _currentLane = 1;
        Vector3 startPos = new(LaneX[_currentLane], 0.0f, PlayerZ);
        _playerRoot.Transform.Position = startPos;
        _laneTween = new Tween(startPos, startPos, 0.15f, Easing.EaseOut);

        _verticalSpeed = 0.0f;
        _jumpHeight = 0.0f;
        _playerBody.Transform.Position = new Vector3(0.0f, PlayerY, 0.0f);

        _worldSpeed = 11.0f;
        _spawnTimer = 0.6f;
        _score = 0.0f;
        _gameOver = false;
    }

    public override void Update(float dt, Input input)
    {
        if (input.WasPressed(RestartAction))
        {
            ResetGame();
            ConsolePanel.PrintMessage("joc nou");
            return;
        }

        if (_gameOver || dt <= 0.0f) return;

        // 1. Scorul și accelerarea treptată a lumii
        _score += dt;
        _worldSpeed += 0.35f * dt;

        // 2. Schimbarea benzii cu Tween (EaseOut, 0.15 s < 0.2 s)
        if (input.WasPressed(MoveLeft) && _currentLane > 0)
        {
            _currentLane--;
            _laneTween.GoTo(new Vector3(LaneX[_currentLane], 0.0f, PlayerZ), 0.15f);
        }
        if (input.WasPressed(MoveRight) && _currentLane < LaneX.Length - 1)
        {
            _currentLane++;
            _laneTween.GoTo(new Vector3(LaneX[_currentLane], 0.0f, PlayerZ), 0.15f);
        }

        _laneTween.Update(dt);
        _playerRoot.Transform.Position = _laneTween.Value;

        // 3. Saltul cu gravitație
        if (_jumpHeight <= 0.0f && input.WasPressed(JumpAction))
        {
            _verticalSpeed = JumpSpeed;
        }

        if (_jumpHeight > 0.0f || _verticalSpeed > 0.0f)
        {
            _verticalSpeed -= Gravity * dt;
            _jumpHeight += _verticalSpeed * dt;
            if (_jumpHeight <= 0.0f)
            {
                _jumpHeight = 0.0f;
                _verticalSpeed = 0.0f;
            }
        }
        _playerBody.Transform.Position = new Vector3(0.0f, PlayerY + _jumpHeight, 0.0f);

        // 4. BONUS: deplasarea marcajelor pe drum
        foreach (SceneObject stripe in _roadStripes)
        {
            stripe.Transform.Position.Z += _worldSpeed * dt;
            if (stripe.Transform.Position.Z > 8.0f)
            {
                stripe.Transform.Position.Z -= 12 * 4.2f;
            }
        }

        // 5. Generarea obstacolelor (frecvența crește odată cu viteza)
        _spawnTimer -= dt;
        if (_spawnTimer <= 0.0f)
        {
            SpawnWave();
            float interval = MathF.Max(0.55f, 14.0f / _worldSpeed);
            _spawnTimer = interval;
        }

        // 6. Deplasarea obstacolelor și testul de coliziune AABB
        Vector3 playerCenter = _playerBody.WorldPosition;
        Vector3 playerHalf = new(0.42f, 0.45f, 0.42f);

        for (int i = _obstacles.Count - 1; i >= 0; i--)
        {
            Obstacle obs = _obstacles[i];
            obs.Obj.Transform.Position.Z += _worldSpeed * dt;

            if (OverlapsAabb(playerCenter, playerHalf, obs.Obj.WorldPosition, obs.HalfExtents))
            {
                _gameOver = true;
                if (_score > _bestScore) _bestScore = _score;
                ConsolePanel.PrintMessage($"coliziune! scor: {_score:F2} s (record: {_bestScore:F2} s)");
                return;
            }

            if (obs.Obj.Transform.Position.Z > 11.0f)
            {
                Objects.Remove(obs.Obj);
                _obstacles.RemoveAt(i);
            }
        }
    }

    private void SpawnWave()
    {
        // Blocăm 1 sau 2 benzi, lăsând mereu cel puțin o bandă liberă
        int blockedCount = _rng.NextDouble() < 0.45 ? 2 : 1;
        int firstLane = _rng.Next(0, 3);

        for (int k = 0; k < blockedCount; k++)
        {
            int lane = (firstLane + k) % 3;
            bool isTall = _rng.NextDouble() < 0.45;
            float height = isTall ? 2.4f : 0.85f;

            SceneObject obj = AddObject("obstacol", _cubeMesh);
            obj.Transform.Position = new Vector3(LaneX[lane], height / 2.0f, -40.0f);
            obj.Transform.Scale = new Vector3(1.3f, height, 1.0f);
            obj.Tint = isTall
                ? new Color4(0.85f, 0.25f, 0.65f, 1.0f)   // obstacol înalt (se ocolește)
                : new Color4(0.95f, 0.45f, 0.2f, 1.0f);   // obstacol jos (se poate sări)

            _obstacles.Add(new Obstacle
            {
                Obj = obj,
                HalfExtents = new Vector3(0.62f, height * 0.48f, 0.48f),
                IsTall = isTall
            });
        }
    }

    private static bool OverlapsAabb(Vector3 centerA, Vector3 halfA, Vector3 centerB, Vector3 halfB)
    {
        return MathF.Abs(centerA.X - centerB.X) < (halfA.X + halfB.X)
            && MathF.Abs(centerA.Y - centerB.Y) < (halfA.Y + halfB.Y)
            && MathF.Abs(centerA.Z - centerB.Z) < (halfA.Z + halfB.Z);
    }

    public override IEnumerable<string> Describe()
    {
        foreach (string line in base.Describe()) yield return line;
        yield return $"Stare joc      : {(_gameOver ? "GAME OVER" : "în desfășurare")}   banda: {_currentLane + 1}/3";
        yield return $"Scor / record  : {_score:F2} s / {_bestScore:F2} s   viteză: {_worldSpeed:F1} u/s";
        yield return $"Obstacole      : {_obstacles.Count} active";
    }
}