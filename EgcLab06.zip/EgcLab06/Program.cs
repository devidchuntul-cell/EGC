using Egc;

// Program.cs conține DOAR inițializarea aplicației:
// creăm fereastra (clasa Game) și pornim bucla principală.
using var game = new Game(1024, 640, "EGC – Laborator 06");
game.Run();
